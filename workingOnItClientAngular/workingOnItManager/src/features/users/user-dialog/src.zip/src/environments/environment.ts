export const environment = {
  production: false,
  apiUrl: "https://workingonitserver.onrender.com/api",
}
