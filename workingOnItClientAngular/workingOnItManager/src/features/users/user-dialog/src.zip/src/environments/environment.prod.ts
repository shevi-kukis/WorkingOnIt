export const environment = {
  production: true,
  apiUrl: "https://workingonitserver.onrender.com/api",
}
